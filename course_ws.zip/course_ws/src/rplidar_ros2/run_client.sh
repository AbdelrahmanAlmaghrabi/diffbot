#!/bin/bash
source ./install/setup.bash
ros2 run rplidar_ros rplidarNodeClient 
















