#!/bin/bash
source ./install/setup.bash
ros2 run tf2_ros static_transform_publisher 0 0 0 0 0 0  world laser_frame  



















