#!/bin/bash

source /opt/ros/foxy/setup.bash


source ~/course_ws/install/setup.bash

ros2 launch diff_bot robot.launch.py
