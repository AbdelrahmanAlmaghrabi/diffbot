#!/bin/bash

# Function to handle user input
handle_input() {
    read -p "Enter your command (save / save_inplace): " input
    case $input in
        save)
            ros2 run nav2_map_server map_saver_cli -f map
            kill_xterm_and_exit
            ;;
        save_inplace)
            cd ~/course_ws/src/bot_nav/config
            ros2 run nav2_map_server map_saver_cli -f obs_map
            cd ~/course_ws
            colcon build --packages-select bot_nav
            kill_xterm_and_exit
            ;;
        *)
            echo "Invalid command. Please enter either 'save' or 'save_inplace'."
            ;;
    esac
}

# Function to kill the xterm process and exit
kill_xterm_and_exit() {
    kill "$xterm_pid"
    exit 0
}

# Run the mapping launch file
echo "Running Navigation Launch file."
source /opt/ros/foxy/setup.bash
source ~/course_ws/install/setup.bash
xterm -e "ros2 launch bot_nav mapping.launch.py" &
xterm_pid=$!

# Continuous prompt for user input
while true; do
    handle_input
done
