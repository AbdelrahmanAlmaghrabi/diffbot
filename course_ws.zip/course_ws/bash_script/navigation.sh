#!/bin/bash


#Run the Navigation launch file




echo "Running Naviagation launch file."

source /opt/ros/foxy/setup.bash 

source ~/course_ws/install/setup.bash
ros2 launch bot_nav navigation.launch.py

